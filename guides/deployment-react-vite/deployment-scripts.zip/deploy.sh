#!/bin/bash

# Get all directories in ~/www/
echo "Available projects:"
mapfile -t directories < <(find ~/www -maxdepth 1 -mindepth 1 -type d -exec basename {} \; | sort)

# Display directories with numbers
for i in "${!directories[@]}"; do
    echo "$((i+1)). ${directories[$i]}"
done

# Ask user to select a project
echo -n "Select a project number: "
read -r selection

# Validate input
if ! [[ "$selection" =~ ^[0-9]+$ ]] || [ "$selection" -lt 1 ] || [ "$selection" -gt "${#directories[@]}" ]; then
    echo "Invalid selection. Exiting."
    exit 1
fi

# Get the selected project name
project_machine_name="${directories[$((selection-1))]}"
echo "Selected project: $project_machine_name"

# git pull and exit if no changes
cd ~/www/"$project_machine_name" || exit
git reset --hard HEAD
RESULT=$(git pull)
if [ "$RESULT" == "Already up to date." ]; then
    echo "No Git changes"
    exit
fi

#run scripts and rsync to production folder
npm install
npm run build
sudo rsync --quiet -av --delete ~/www/"$project_machine_name"/dist/ /var/www/production/

#fix rights for folders/files
sudo chown -R www-data:www-data /var/www/production
sudo find /var/www/production -type d -exec chmod 775 {} \;
sudo find /var/www/production -type f -exec chmod 664 {} \;
